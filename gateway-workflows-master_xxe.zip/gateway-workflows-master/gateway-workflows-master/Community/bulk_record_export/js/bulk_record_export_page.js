// Copyright 2019 BlueCat Networks. All rights reserved.
// JavaScript for your page goes in here.
function custom_js_table_loaded(data) {
    console.log("on_complete custom function called");
}