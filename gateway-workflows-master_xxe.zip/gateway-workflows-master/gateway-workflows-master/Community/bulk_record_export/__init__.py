# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'bulk_record_export_page',
        'title'       : u' Bulk Record Export',
        'endpoint'    : 'bulk_record_export/bulk_record_export_endpoint',
        'description' : u'bulk_record_export'
    },
]
