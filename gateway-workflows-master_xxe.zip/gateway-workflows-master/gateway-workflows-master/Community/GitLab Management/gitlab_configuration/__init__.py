# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'gitlab_configuration_page',
        'title'       : u'GitLab Configuration',
        'endpoint'    : 'gitlab_configuration/gitlab_configuration_endpoint',
        'description' : u'gitlab_configuration'
    },
]
