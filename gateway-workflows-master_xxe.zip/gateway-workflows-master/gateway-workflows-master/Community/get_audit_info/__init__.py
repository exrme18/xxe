# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'get_audit_info_page',
        'title'       : u'Get Audit Info',
        'endpoint'    : 'get_audit_info/get_audit_info_endpoint',
        'description' : u'get_audit_info'
    },
]
