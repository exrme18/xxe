// Copyright 2020 BlueCat Networks. All rights reserved.
// JavaScript for your page goes in here.
$( document ).ready(function() {
    $("#network_name, #network_location, #network_size, #submit").prop('disabled', false)
});
