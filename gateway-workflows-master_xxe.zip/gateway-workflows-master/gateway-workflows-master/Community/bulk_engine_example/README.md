<!-- Copyright 2019 BlueCat Networks. All rights reserved. -->

©2019 BlueCat Networks (USA) Inc. and its affiliates (collectively ‘ BlueCat’). All rights reserved. This document contains BlueCat confidential and proprietary information and is intended only for the person(s) to whom it is transmitted. Any reproduction of this document, in whole or in part, without the prior written consent of BlueCat is prohibited.

Workflow Version: 20.3.1 <br/>
Project Title: Bulk Engine Example Workflow <br/>
Author: Chris Storz <br/>
Date: 03-02-2020 <br/>
BlueCat Gateway Version: 20.0.1 <br/>
BAM / BDDS Version: 8.1.1+ <br/>
Dependencies: Bulk Engine Library (BlueCat Github) <br/>
Installation Directions: Standard workflow installation <br/>
Known Errors and Bugs: No input validation <br/>
Description/Example Usage: Fields are prepopulated with usable data for examples<br/>
BAM API methods: Get Entity By ID <br/>
Change Log: N/A <br/>
