# Copyright 2019 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'bulk_engine_example_page',
        'title'       : u'Bulk Example',
        'endpoint'    : 'bulk_engine_example/bulk_example',
        'description' : u'bulk_engine_example'
    },
]
