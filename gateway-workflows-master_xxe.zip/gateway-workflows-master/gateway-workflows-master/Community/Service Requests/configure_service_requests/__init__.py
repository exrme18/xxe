# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'configure_service_requests_page',
        'title'       : u'Configure Service Requests',
        'endpoint'    : 'configure_service_requests/configure_service_requests_endpoint',
        'description' : u'configure_service_requests'
    },
]
