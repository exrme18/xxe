# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'move_to_bluecatgateway_udf_page',
        'title'       : u'Migrate to BlueCatGateway UDF',
        'endpoint'    : 'move_to_bluecatgateway_udf/move_to_bluecatgateway_udf_endpoint',
        'description' : u'move_to_bluecatgateway_udf'
    },
]
