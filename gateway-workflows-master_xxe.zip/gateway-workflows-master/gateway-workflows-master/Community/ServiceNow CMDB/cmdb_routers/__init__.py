# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'cmdb_routers_page',
        'title'       : u'CMDB Routers',
        'endpoint'    : 'cmdb_routers/cmdb_routers_endpoint',
        'description' : u'cmdb_routers'
    },
]
