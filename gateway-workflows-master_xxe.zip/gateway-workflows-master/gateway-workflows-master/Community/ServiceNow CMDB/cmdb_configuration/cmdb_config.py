servicenow_url = 'https://service-now.com'
servicenow_username = 'bill.morton'
servicenow_secret_file = 'workflows/ServiceNow CMDB/cmdb_configuration/.secret'
servicenow_max_query_results = '1000'

