# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'cmdb_network_gear_page',
        'title'       : u'CMDB Network Gear',
        'endpoint'    : 'cmdb_network_gear/cmdb_network_gear_endpoint',
        'description' : u'cmdb_network_gear'
    },
]
