# Copyright 2020 BlueCat Networks. All rights reserved.

# Default Configuration ID
DEFAULT_CONFIG_NAME = 'Default'
# Default View ID
DEFAULT_VIEW_NAME = 'test1'
DEFAULT_VIEW_ID = 100910
