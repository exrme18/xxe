# Copyright 2020 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'api'
sub_pages = [
    {
        'name'        : 'manage_records',
        'title'       : 'manage_records',
        'endpoint'    : 'manage_records/endpoint',
        'description' : 'manage_records'
    },
]
